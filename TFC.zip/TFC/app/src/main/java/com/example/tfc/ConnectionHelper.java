package com.example.tfc;

import android.os.StrictMode;
import android.util.Log;

import java.net.ConnectException;
import java.sql.Connection;

public class ConnectionHelper {

}
