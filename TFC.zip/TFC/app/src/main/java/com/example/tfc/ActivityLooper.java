package com.example.tfc;

import androidx.appcompat.app.AppCompatActivity;

import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.ToneGenerator;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

import java.util.Timer;
import java.util.TimerTask;

public class ActivityLooper extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener, CompoundButton.OnCheckedChangeListener, View.OnClickListener {
    TextView tvbpm;
    Button canal1, canal2, canal3, canal4, startStop;
    SeekBar sliderBpm;

    Switch metronomo;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_looper);
        tvbpm=(TextView) findViewById(R.id.tvbpm);
        metronomo=(Switch) findViewById(R.id.switchMetronomo);
        canal1=(Button) findViewById(R.id.btLooper1);
        canal2=(Button) findViewById(R.id.btLooper2);
        canal3=(Button) findViewById(R.id.btLooper3);
        canal4=(Button) findViewById(R.id.btLooper4);
        startStop=(Button) findViewById(R.id.btLooperStart);
        sliderBpm=(SeekBar) findViewById(R.id.seekBarBpm);
        tvbpm.setText(""+0);

        sliderBpm.setOnSeekBarChangeListener(this);
        metronomo.setOnCheckedChangeListener(this);
        startStop.setOnClickListener(this);



      metronomo.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

            }
        });
    }

    public void metronomo(){
        Timer timer = new Timer();
        int tempo = Integer.parseInt(String.valueOf(tvbpm.getText()));
        tempo = tempo/60;
        int delay = tempo*1000;

        ToneGenerator toneGen1 = new ToneGenerator(AudioManager.STREAM_MUSIC, 100);

        TimerTask tarea = new TimerTask() {
            @Override
            public void run() {
                if(metronomo.isChecked()){
                toneGen1.startTone(ToneGenerator.TONE_CDMA_PIP,150);
            }}
        };timer.schedule(tarea,0, delay );
    }
    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        sliderBpm.setProgress(i*3);

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }


    @Override
    public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

    }

    @Override
    public void onClick(View view) {
            if(metronomo.isChecked()){
                metronomo();
            }else {


            }
        }

}